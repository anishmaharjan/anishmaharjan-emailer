'use strict';

/*
*
* endpoints:
  GET - https://l9x867e9wc.execute-api.us-east-1.amazonaws.com/dev/
  POST - https://l9x867e9wc.execute-api.us-east-1.amazonaws.com/dev/sendmail
*
* */

module.exports.home = async event => {
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Go Serverless v1.0! Your function executed successfully!',
        input: event,
      },
      null,
      2
    ),
  };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};

module.exports.sendMail = async event => {
  // https://github.com/sendgrid/sendgrid-nodejs

  const sgMail = require('@sendgrid/mail');
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  const msg = {
    to: 'gara.knoe@gmail.com',
    from: 'anish@anishmaharjan.com',
    subject: 'Sending with Twilio SendGrid is Fun',
    text: 'and easy to do anywhere, even with Node.js',
    html: '<strong>and easy to do anywhere, even with Node.js</strong>',
  };
  sgMail.send(msg);

  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Send mail',
        input: event,
      },
      null,
      2
    ),
  };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};
